package tdt.Hothinhphat.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Price {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_price")
	private int price;

	public int getId() {
		return price;
	}

	public void setId(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private String name;

}//create table mapping trong db

-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2023 at 08:33 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `giuaky`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `name` varchar(255) NOT NULL,
  `category_id` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`name`, `category_id`) VALUES
('Nam', 1),
('Nữ', 2),
('Unisex', 3);

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `category_price` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL,
  `weight` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `description`, `image_name`, `name`, `price`, `weight`, `category_id`) VALUES
(1, 'Vì là sản phẩm nước hoa xịt tóc nên sẽ ít cồn hơn rất nhiều, khi các bạn xịt lên tóc cũng sẽ không bị cảm giác khô, rít hay bết tóc như các loại nước hoa thông thường. Bên cạnh đó, một lợi ích nữa của nước hoa xịt tóc đó là tóc là một nơi lưu giữ mùi cực kì tốt, vậy nên các bạn sẽ có một mùi hương sang trọng, nổi bật, bám lâu trên tóc nhưng chỉ tỏa ở mức vừa phải nên rất hợp sử dụng vào những ngày mùa hè. ', 'AnotherU.png', 'Another', 2400000, 1000, 3),
(2, 'Mùi hương của Madame M không hề dễ đoán, dễ nắm bắt, dễ bóc tách ra các đơn nốt rõ ràng. Rất ít khi ta gặp một mùi hương của nữ được làm theo hướng woody cay ấm, với nhân vật chính là gỗ tuyết tùng, bạch đậu khấu cùng với hoắc hương. Như tôi đã nói, chính bản thân tôi còn thấy nó khó nắm bắt và bóc tách, nên sẽ khó mà review mùi hương này theo hướng thông thường được. ', 'Aventus.png', 'Aventus', 2500000, 500, 2),
(3, 'Creed Aventus tôn vinh sức mạnh, tầm nhìn và sự thành công, lấy cảm hứng từ cuộc sống đầy giai thoại giữa chiến tranh, hòa bình và sự lãng mạn của hoàng đế Napoleon. Nhắc đến Aventus hẳn những ai yêu thích nước hoa đều phải dành cho nó nhiều mỹ từ, và từ ngữ miêu tả về nó một cách chân thật nhất đó là “vua” của nước hoa. Aventus có hương mở đầu với trái cây tươi mát đầy ngọt ngào của cam bergamot, táo và dứa, và đặc biệt là quả lý chua đen. Lớp hương giữa có pha trộn gia vị cay nồng và hương gỗ ', 'BaccaratN.png', 'Cress Aventus', 1990000, 500, 1),
(4, 'Cape Heartache chính là chai nước hoa best-seller của nhà nước hoa quốc tịch Mỹ Imaginary Authors. Rất nhiều người cho rằng, ngửi Cape Heartache cho họ cảm giác như đang đi du lịch ở Đà Lạt hoặc một vùng núi cao nào đó, rời xa chốn đô thị phồn hoa náo nhiệt để tìm cho mình sự bình yên, tạm gác lại những mệt mỏi và âu lo trong cuộc sống. Cape Heartache như đưa ta về với một sườn núi thơ mộng vào ban sớm, khi mà ánh nắng mặt trời còn chưa chiếu rọi qua làn sương mù, nhắm mắt lại, tận hưởng không k', 'BergamotU.png', 'Bergmot', 4000000, 500, 3),
(5, 'Cape Heartache chính là chai nước hoa best-seller của nhà nước hoa quốc tịch Mỹ Imaginary Authors. Rất nhiều người cho rằng, ngửi Cape Heartache cho họ cảm giác như đang đi du lịch ở Đà Lạt hoặc một vùng núi cao nào đó, rời xa chốn đô thị phồn hoa náo nhiệt để tìm cho mình sự bình yên, tạm gác lại những mệt mỏi và âu lo trong cuộc sống. Cape Heartache như đưa ta về với một sườn núi thơ mộng vào ban sớm, khi mà ánh nắng mặt trời còn chưa chiếu rọi qua làn sương mù, nhắm mắt lại, tận hưởng không k', 'WoodU.png', 'Wood', 2345678, 500, 3),
(6, 'Vừa xịt Vetiver Santal ra, ta sẽ nhận thấy rõ mùi chanh đắng khá êm dịu quyện với mùi cam bergamote fresh, xanh ngát và hơi chua chua tạo nên một cái mở đầu rất dễ chịu, tinh tế và trong trẻo tựa một chuyến dạo chơi nơi một vùng quê thanh bình yên ả không chút ồn ào trong một buổi chiều nắng nhẹ. Cái opening này của Vetiver Santal không bị cảm giác bùng nổ theo hướng những mùi hương cùng kiểu mở đầu cam chanh, có lẽ vì một chút sắc thái gỗ cũng xuất hiện giữ mùi hương lại không bị vồn vã quá, mộ', 'Imaginary.jpg', 'Imaginary', 2399000, 500, 3),
(7, 'Vừa xịt Vetiver Santal ra, ta sẽ nhận thấy rõ mùi chanh đắng khá êm dịu quyện với mùi cam bergamote fresh, xanh ngát và hơi chua chua tạo nên một cái mở đầu rất dễ chịu, tinh tế và trong trẻo tựa một chuyến dạo chơi nơi một vùng quê thanh bình yên ả không chút ồn ào trong một buổi chiều nắng nhẹ. Cái opening này của Vetiver Santal không bị cảm giác bùng nổ theo hướng những mùi hương cùng kiểu mở đầu cam chanh, có lẽ vì một chút sắc thái gỗ cũng xuất hiện giữ mùi hương lại không bị vồn vã quá, mộ', 'LostN.png', 'Lost', 3399000, 500, 1),
(8, 'Mùi hương của Madame M không hề dễ đoán, dễ nắm bắt, dễ bóc tách ra các đơn nốt rõ ràng. Rất ít khi ta gặp một mùi hương của nữ được làm theo hướng woody cay ấm, với nhân vật chính là gỗ tuyết tùng, bạch đậu khấu cùng với hoắc hương. Như tôi đã nói, chính bản thân tôi còn thấy nó khó nắm bắt và bóc tách, nên sẽ khó mà review mùi hương này theo hướng thông thường được. ', 'Marie.png', 'Marie', 3000000, 500, 1),
(9, 'Vì là sản phẩm nước hoa xịt tóc nên sẽ ít cồn hơn rất nhiều, khi các bạn nữ xịt lên tóc cũng sẽ không bị cảm giác khô, rít hay bết tóc như các loại nước hoa thông thường. Bên cạnh đó, một lợi ích nữa của nước hoa xịt tóc đó là tóc là một nơi lưu giữ mùi cực kì tốt, vậy nên các bạn sẽ có một mùi hương sang trọng, nổi bật, bám lâu trên tóc nhưng chỉ tỏa ở mức vừa phải nên rất hợp sử dụng vào những ngày mùa hè. ', 'NasomatoN.png', 'Nasomato', 3700000, 500, 2),
(10, 'Cape Heartache chính là chai nước hoa best-seller của nhà nước hoa quốc tịch Mỹ Imaginary Authors. Rất nhiều người cho rằng, ngửi Cape Heartache cho họ cảm giác như đang đi du lịch ở Đà Lạt hoặc một vùng núi cao nào đó, rời xa chốn đô thị phồn hoa náo nhiệt để tìm cho mình sự bình yên, tạm gác lại những mệt mỏi và âu lo trong cuộc sống. Cape Heartache như đưa ta về với một sườn núi thơ mộng vào ban sớm, khi mà ánh nắng mặt trời còn chưa chiếu rọi qua làn sương mù, nhắm mắt lại, tận hưởng không k', 'Orto.png', 'Orto', 5500000, 500, 2);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'ROLE_ADMIN'),
(2, 'ROLE_USER');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `first_name`, `last_name`, `password`) VALUES
(3, 'hothinhphatvd4@gmail.com', 'Ho', 'Thinh Phat', '$2a$10$BAExDU6CEWaeZvOLp9Hbp..bIFWzabTkcakIgYDOTSNBxeUAeLXVS'),
(4, '1@gmail.com', 'Ho', 'Thinh Phat', '$2a$10$ZwPEpNe3wIep1Wv.4lZ/5unmhUJ22cOb3GYRbyy3rf8LWgAx5Oc0S'),
(5, 'admin@gmail.com', 'admin', 'admin', '$2a$10$ZwPEpNe3wIep1Wv.4lZ/5unmhUJ22cOb3GYRbyy3rf8LWgAx5Oc0S'),
(6, 'hothinhphat2000@gmail.com', 'Ho', 'Thinh Phat', '$2a$10$J..lGReEm2ZRpEdKvHdL8.Ne2LPKh9H/wxAQWvndzyElRAlKSk4J2');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `role_id`) VALUES
(4, 3, 1),
(5, 3, 2),
(6, 4, 1),
(7, 4, 2),
(8, 6, 1),
(9, 6, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`category_price`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id_foreign_key` (`category_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKj345gk1bovqvfame88rcx7yyx` (`user_id`),
  ADD KEY `FKt7e7djp752sqn6w22i6ocqy6q` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `category_price` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `category_id_foreign_key` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `FKj345gk1bovqvfame88rcx7yyx` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `FKt7e7djp752sqn6w22i6ocqy6q` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
